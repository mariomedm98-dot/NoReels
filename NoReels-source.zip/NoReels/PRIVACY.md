# Privacy statement

NoReels 0.1.0 has no network permission and includes no network client libraries. It has no analytics or telemetry implementation. It does not request contacts, media, camera, microphone, location, or file permissions. The AccessibilityService locally inspects visible accessibility labels in the foreground app to decide whether to display a blocking overlay. No screen text is written to persistent storage. App toggles are stored locally using Android SharedPreferences.

Because Accessibility is a sensitive Android capability, users must enable the service themselves in system settings. Disabling the service in Android Accessibility settings stops detection and overlay behavior.
