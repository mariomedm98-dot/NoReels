# NoReels — Android prototype 0.1.0

NoReels is a local-only Android AccessibilityService prototype intended to detect and cover short-video screens in Instagram, TikTok and YouTube.

## Privacy by design

- The manifest deliberately contains **no `INTERNET` permission**.
- No analytics, telemetry, ads, account, backend, SDK, or network dependency.
- No contacts, camera, microphone, location, or storage permissions.
- Preferences are stored locally in Android SharedPreferences.
- The AccessibilityService reads visible accessibility labels locally to identify target screens. It does not save or transmit screen text.

## Important limitations

This is an early prototype, not a guaranteed universal blocker. Instagram, TikTok and YouTube are third-party apps and can change their labels and layouts at any time. The detection rules are heuristic and may miss screens or occasionally block a non-target screen. Instagram feed Reels are particularly difficult to distinguish from ordinary video posts through public Android accessibility APIs. This prototype covers a detected target screen with a full-screen Accessibility overlay; it does not modify the third-party apps or remove their native UI elements.

TikTok's For You feed is its primary short-video experience. Blocking that feed while preserving other TikTok areas depends on the app exposing enough distinct accessibility labels. YouTube Shorts and Instagram Reels detection also depends on labels exposed by the installed app version and language. Current rules are English-oriented; localization support should be added after testing on the target phone.

## Build

Requirements: Android Studio (recent stable), JDK 17 or 21, Android SDK Platform 35, Android Gradle Plugin 8.7.3.

1. Open this folder in Android Studio.
2. Let Gradle sync and install missing Android SDK components if prompted.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

For command line, from this folder run `gradle assembleDebug` after installing Gradle and Android SDK. The repository does not include a Gradle wrapper binary.

## Install and enable

1. Install the APK on the phone.
2. Open NoReels and enable **NoReels: bloqueo de vídeos cortos** in Android Accessibility settings.
3. Return to NoReels and leave the desired app switches enabled.
4. Test each target app. If detection is inaccurate, disable that app's switch until the rules are adjusted.

## Permission warning

Android Accessibility is a powerful permission: an enabled service can inspect accessibility information exposed by the foreground app and can perform UI actions. NoReels needs it to recognize target screens and display its blocking overlay. Android requires the user to enable it manually. Only install builds you have compiled or otherwise trust, and review the source before enabling the service.

## Package IDs

- Instagram: `com.instagram.android`
- TikTok: `com.zhiliaoapp.musically`
- YouTube: `com.google.android.youtube`
