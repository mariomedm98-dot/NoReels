package com.noreels.app

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Local-only prototype. It never opens a socket and the app manifest has no INTERNET permission.
 * Detection is heuristic because third-party apps change their accessibility labels frequently.
 */
class BlockerService : AccessibilityService() {
    companion object {
    const val PREFS = "noreels_local_settings"
    const val KEY_INSTAGRAM = "block_instagram"
    const val KEY_TIKTOK = "block_tiktok"
    const val KEY_YOUTUBE = "block_youtube"
    private const val PKG_INSTAGRAM = "com.instagram.android"
    private const val PKG_TIKTOK = "com.zhiliaoapp.musically"
    private const val PKG_YOUTUBE = "com.google.android.youtube"
    }

    private var overlay: LinearLayout? = null
    private var lastBlockedAt = 0L
    private var lastPackage: String? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val enabled = when (pkg) {
            PKG_INSTAGRAM -> prefs.getBoolean(KEY_INSTAGRAM, true)
            PKG_TIKTOK -> prefs.getBoolean(KEY_TIKTOK, true)
            PKG_YOUTUBE -> prefs.getBoolean(KEY_YOUTUBE, true)
            else -> false
        }
        if (!enabled) { removeOverlay(); return }
        val root = rootInActiveWindow ?: return
        val labels = collectLabels(root).joinToString(" | ").lowercase()
        val shouldBlock = when (pkg) {
            PKG_INSTAGRAM -> isInstagramReel(labels)
            PKG_TIKTOK -> isTikTokForYou(labels)
            PKG_YOUTUBE -> isYouTubeShorts(labels)
            else -> false
        }
        if (shouldBlock) showOverlay(pkg) else if (lastPackage != pkg || overlay != null) removeOverlay()
        lastPackage = pkg
    }

    private fun collectLabels(root: AccessibilityNodeInfo): List<String> {
        val found = ArrayList<String>()
        fun walk(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || depth > 18 || found.size > 500) return
            node.text?.toString()?.takeIf { it.isNotBlank() }?.let(found::add)
            node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let(found::add)
            for (i in 0 until node.childCount) walk(node.getChild(i), depth + 1)
        }
        walk(root, 0)
        return found
    }

    // Conservative rules: require multiple page-specific labels to reduce false positives.
    private fun isInstagramReel(s: String): Boolean {
        val reelContext = listOf("original audio", "use audio", "remix", "reels viewer", "reel by", "リール", "音源を使用", "オリジナル音源", "リミックス")
        return reelContext.any { s.contains(it) } &&
            listOf("comment", "like", "share", "audio", "コメント", "いいね", "シェア").any { s.contains(it) }
    }

    private fun isTikTokForYou(s: String): Boolean {
        val home = s.contains("for you") || s.contains("おすすめ")
        val following = s.contains("following") || s.contains("フォロー中") || s.contains("inbox") || s.contains("受信箱")
        val actions = listOf("like", "comment", "share", "いいね", "コメント", "シェア").any { s.contains(it) }
        return home && following && actions
    }

    private fun isYouTubeShorts(s: String): Boolean {
        val shorts = s.contains("shorts") || s.contains("ショート")
        val actions = listOf("comments", "comment", "remix", "コメント", "リミックス").any { s.contains(it) }
        val channel = listOf("subscribe", "like", "dislike", "チャンネル登録", "高評価").any { s.contains(it) }
        return shorts && actions && channel
    }

    private fun showOverlay(pkg: String) {
        val now = System.currentTimeMillis()
        if (overlay != null || now - lastBlockedAt < 1200) return
        lastBlockedAt = now
        val title = when (pkg) {
            PKG_INSTAGRAM -> "Instagram Reels bloqueado"
            PKG_TIKTOK -> "Feed Para ti bloqueado"
            else -> "YouTube Shorts bloqueado"
        }
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(0xF0182530.toInt())
            addView(TextView(context).apply {
                text = "NoReels\n\n$title\n\nEsta sección está desactivada. Puedes volver atrás y seguir usando el resto de la aplicación."
                textSize = 21f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(0xFFFFFFFF.toInt())
                gravity = Gravity.CENTER
            })
            addView(Button(context).apply {
                text = "Volver atrás"
                setOnClickListener {
                    removeOverlay()
                    performGlobalAction(GLOBAL_ACTION_BACK)
                }
            })
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        try { wm.addView(panel, params); overlay = panel } catch (_: Exception) { overlay = null }
    }

    private fun removeOverlay() {
        val panel = overlay ?: return
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(panel) } catch (_: Exception) { }
        overlay = null
    }

    override fun onInterrupt() { removeOverlay() }
    override fun onDestroy() { removeOverlay(); super.onDestroy() }
}
