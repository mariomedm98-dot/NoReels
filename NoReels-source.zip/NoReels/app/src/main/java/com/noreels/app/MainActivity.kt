package com.noreels.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(BlockerService.PREFS, MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(0xFF101820.toInt())
        }
        fun text(value: String, size: Float, color: Int = 0xFFFFFFFF.toInt()): TextView = TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
        }
        root.addView(text("NoReels", 30f))
        root.addView(text("Bloquea vídeos cortos. Mantén el resto de tus aplicaciones.", 15f, 0xFFB8C7D1.toInt()))
        root.addView(text("\nAPLICACIONES", 13f, 0xFF55D6A4.toInt()))

        addToggle(root, "Instagram · Reels", BlockerService.KEY_INSTAGRAM, true)
        addToggle(root, "TikTok · feed Para ti", BlockerService.KEY_TIKTOK, true)
        addToggle(root, "YouTube · Shorts", BlockerService.KEY_YOUTUBE, true)

        val privacy = text("\nPRIVACIDAD\n• Sin permiso de Internet en el manifiesto\n• Sin telemetría, anuncios ni cuentas\n• Sin acceso a contactos, cámara, ubicación o archivos\n• El permiso de Accesibilidad sí puede leer elementos visibles de pantalla; se usa localmente para detectar las pantallas objetivo.", 14f, 0xFFE0E8ED.toInt())
        root.addView(privacy)

        val settings = Button(this).apply {
            text = "Activar servicio de Accesibilidad"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        root.addView(settings, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(text("\nDespués de activarlo, vuelve a NoReels. Si una aplicación cambia su interfaz, puede ser necesario actualizar las reglas.", 13f, 0xFFB8C7D1.toInt()))
        setContentView(root)
    }

    private fun addToggle(root: LinearLayout, label: String, key: String, default: Boolean) {
        val toggle = Switch(this).apply {
            text = label
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            isChecked = prefs.getBoolean(key, default)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() }
            setPadding(0, 18, 0, 18)
        }
        root.addView(toggle, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }
}
